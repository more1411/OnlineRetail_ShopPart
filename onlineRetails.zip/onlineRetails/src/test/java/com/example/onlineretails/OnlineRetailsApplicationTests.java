package com.example.onlineretails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineRetailsApplicationTests {

    @Test
    void contextLoads() {
    }

}
