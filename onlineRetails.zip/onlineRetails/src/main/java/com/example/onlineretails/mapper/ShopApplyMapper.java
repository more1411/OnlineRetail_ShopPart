package com.example.onlineretails.mapper;

import com.example.onlineretails.entity.ShopApply;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

import java.util.List;

@Mapper
public interface ShopApplyMapper {
    //插入一条申请
    @Insert("insert into shop_apply values (#{apply.shopApplyId},#{apply.userId},#{apply.applyInfoLink},#{apply.applyTime},#{apply.replyTime},#{apply.agreed})")
    int insertShopApply(@Param("apply") ShopApply apply);
    //查找申请
    @Select("select * from shop_apply where userId=#{id}")
    List<ShopApply> findShopApply(@Param("id") String id);
}
