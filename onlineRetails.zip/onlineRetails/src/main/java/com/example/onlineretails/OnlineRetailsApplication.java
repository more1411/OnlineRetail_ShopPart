package com.example.onlineretails;

import com.example.onlineretails.entity.GoodsInfo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineRetailsApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnlineRetailsApplication.class, args);

    }

}
