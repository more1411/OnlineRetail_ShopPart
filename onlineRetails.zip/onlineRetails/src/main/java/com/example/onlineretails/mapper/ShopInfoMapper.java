package com.example.onlineretails.mapper;

import com.example.onlineretails.entity.ShopInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface ShopInfoMapper {
    //按用户id查找店铺
    @Select("select * from shop_info where userId=#{id}")
    ShopInfo getShopByUserId(@Param("id") String userId);
    //查找店面图片名称
    @Select("select shopPhotoLink from shop_info where shopId=#{id}")
    String getPhotoLinkByShopId(@Param("id") String id);
    //更改店面
    @Update("update shop_info set shopPhotoLink=#{photo} where shopId=#{id}")
    int updateShopPhoto(@Param("id") String id,@Param("photo") String Photo);
}
