package com.example.onlineretails.controller;

import com.example.onlineretails.entity.GoodsInfo;
import com.example.onlineretails.entity.GoodsPhotoInfo;
import com.example.onlineretails.entity.GoodsTypeInfo;
import com.example.onlineretails.service.GoodsPhotoInfoService;
import com.example.onlineretails.service.ShopGoodsService;
import com.example.onlineretails.util.FileTools;
import com.example.onlineretails.util.JsonTools;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.example.onlineretails.util.IdTools.getId;

@RestController
@RequestMapping("/shopgoods")
public class ShopGoodsController {
    public void setService(ShopGoodsService service) {
        this.service = service;
    }

    public ShopGoodsService getService() {
        return service;
    }

    public GoodsPhotoInfoService getGoodsPhotoService() {
        return goodsPhotoService;
    }

    public void setGoodsPhotoService(GoodsPhotoInfoService goodsPhotoService) {
        this.goodsPhotoService = goodsPhotoService;
    }

    @Autowired
    private ShopGoodsService service;
    @Autowired
    private GoodsPhotoInfoService goodsPhotoService;
    //获取当前页所有商品信息
    @RequestMapping("/find.action")
    public String getGoodsListByShopId(Integer pn,Integer rn,String id){
        //商品信息
        PageInfo<GoodsInfo> p = service.getGoodsListByShopId(pn,rn,id);
        List<GoodsInfo> goods = p.getList();
        //商品详细信息
        List<String> idList = new ArrayList<>();
        for(GoodsInfo g : goods){
            idList.add(g.getGoodsId());
        }
        List<List<GoodsTypeInfo>> goodsMessage = service.getMultipleGoodsTypeListByGoodsIdList(idList);
        //商品图片
        List<List<GoodsPhotoInfo>> goodsPhotoList = new ArrayList<>();
        for(String goodsId : idList){
            goodsPhotoList.add(goodsPhotoService.getGoodsPhotosByGoodsId(goodsId));
        }
        //商品价格区间
        List<String> minMaxMoney = new ArrayList<>();
        for(List<GoodsTypeInfo> infoList : goodsMessage){
            Double minMoney = infoList.get(0).getPrice();
            Double maxMoney = infoList.get(0).getPrice();
            for(GoodsTypeInfo goodsType : infoList){
                if(goodsType.getPrice()<minMoney)
                    minMoney = goodsType.getPrice();
                if(goodsType.getPrice()>maxMoney)
                    maxMoney = goodsType.getPrice();
            }
            String money = new String();
            if(minMoney!=maxMoney)
                money = minMoney+"-"+maxMoney;
            else
                money = ""+minMoney;
            minMaxMoney.add(money);
        }
        //商品总量
        long total = p.getTotal();
        //判断有商品出售
        boolean haveGoodsOnSale = service.haveGoodsOnSale(id);

        Map map = new LinkedHashMap();
        map.put("goods",goods);
        map.put("total", total);
        map.put("goodsMessage", goodsMessage);
        map.put("minMaxMoney",minMaxMoney);
        map.put("haveGoodsOnSale",haveGoodsOnSale);
        map.put("goodsPhotoList",goodsPhotoList);
        return JsonTools.querySuccess(map);
    }
    //暂停营业,恢复营业
    @RequestMapping("/changeallcondition.action")
    public String changeAllCondition(String shopId){
        service.changeAllGoodsCondition(shopId);
        return JsonTools.executeSuccess();
    }
    //单一商品暂停售卖回复售卖
    @RequestMapping("/changeonecondition.action")
    public String changeOneCondition(String goodsId){
        service.changeOneGoodsCondition(goodsId);
        return JsonTools.executeSuccess();
    }
    //更改商品库存和价格
    @RequestMapping("/updateSP.action")
    public String updateGoodsStockandPrice(String goodsTypeId,Integer stock,Double price){
        service.updateGoodsStock(goodsTypeId,stock,price);
        return JsonTools.executeSuccess();
    }
    //单一商品上传新的图片
    @RequestMapping("/oneUpdatePhoto.action")
    public String oneGoodsUpPhoto(String goodsId, MultipartFile[] picsFile){
        List<GoodsPhotoInfo> list = new ArrayList();
        for(MultipartFile file : picsFile){
            GoodsPhotoInfo photo = new GoodsPhotoInfo();
            photo.setGoodsPhotoLink(FileTools.writeFile("D:/image/goods/","", file));
            photo.setGoodsPhotoId(getId());
            photo.setGoodsId(goodsId);
            list.add(photo);
        }
        goodsPhotoService.insertPhotoList(list);
        return JsonTools.executeSuccess();
    }
    //上架商品
    @RequestMapping("/upGoods.action")
    public String upGoods(GoodsInfo goods, MultipartFile[] goodsPhoto){
        List<GoodsPhotoInfo> list = new ArrayList();
        String goodsId=goods.getGoodsId();
        for(MultipartFile file : goodsPhoto){
            GoodsPhotoInfo photo = new GoodsPhotoInfo();
            photo.setGoodsPhotoLink(FileTools.writeFile("D:/image/goods/","", file));
            photo.setGoodsPhotoId(getId());
            photo.setGoodsId(goodsId);
            list.add(photo);
        }
        goodsPhotoService.insertPhotoList(list);
        goods.setGoodsPhotosLink(list.get(0).getGoodsPhotoLink());
        goods.setIsSale(1);
        service.upGoods(goods);
        return JsonTools.executeSuccess();
    }
    //上架商品类型
    @RequestMapping("/upGoodsType.action")
    public String upGoodsType(GoodsTypeInfo goodsType){
        String oldId=goodsType.getGoodsTypeId();
        goodsType.setGoodsTypeId(getId()+oldId);
        service.upGoodsType(goodsType);
        return JsonTools.executeSuccess();
    }
    //给前端获取一个id
    @RequestMapping("/getId.action")
    public String getOneId(){
        String id = getId();
        Map map = new LinkedHashMap();
        map.put("id",id);
        return JsonTools.querySuccess(map);
    }
    //删除商品图片
    @RequestMapping("/deletePhoto.action")
    public String deleteGoodsPhoto(String photoId){
        GoodsPhotoInfo photo = goodsPhotoService.getGoodsPhotosByPhotoId(photoId);
        FileTools.deleteFile("D:/image/goods/",photo.getGoodsPhotoLink());
        goodsPhotoService.deleteGoodsPhotosByPhotoId(photoId);
        return JsonTools.executeSuccess();
    }
    //下架商品
    @RequestMapping("/deletegoods.action")
    public String deleteGoods(String goodsId){
        List<GoodsPhotoInfo> photoList=goodsPhotoService.getGoodsPhotosByGoodsId(goodsId);
        for(GoodsPhotoInfo p :photoList){
            FileTools.deleteFile("D:/image/goods/",p.getGoodsPhotoLink());
        }
        service.deleteGoods(goodsId);
        return JsonTools.executeSuccess();
    }
}
