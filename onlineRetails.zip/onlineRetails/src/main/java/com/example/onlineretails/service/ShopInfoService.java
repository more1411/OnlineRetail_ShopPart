package com.example.onlineretails.service;

import com.example.onlineretails.entity.ShopInfo;
import com.example.onlineretails.mapper.ShopInfoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShopInfoService {
    public void setMapper(ShopInfoMapper mapper) {
        this.mapper = mapper;
    }
    @Autowired
    private ShopInfoMapper mapper;

    //按用户id查找店铺
    public ShopInfo getShopByUserId(String userId){
        ShopInfo shop = mapper.getShopByUserId(userId);
        return shop;
    }
    //按shopid查找图片名称
    public String getPhotoNameByShopId(String shopId){
        String n=mapper.getPhotoLinkByShopId(shopId);
        return n;
    }
    //更改店面
    public void updatePhoto(String shopId,String photo){
        mapper.updateShopPhoto(shopId,photo);
    }
}
