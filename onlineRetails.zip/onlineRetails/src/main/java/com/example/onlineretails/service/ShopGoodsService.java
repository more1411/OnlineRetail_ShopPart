package com.example.onlineretails.service;

import com.example.onlineretails.entity.GoodsInfo;
import com.example.onlineretails.entity.GoodsTypeInfo;
import com.example.onlineretails.mapper.GoodsPhotoInfoMapper;
import com.example.onlineretails.mapper.ShopGoodsMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ShopGoodsService {
    public void setMapper(ShopGoodsMapper mapper) {
        this.mapper = mapper;
    }
    @Autowired
    private ShopGoodsMapper mapper;
    public void setMapper(GoodsPhotoInfoMapper photoMapper) {
        this.photoMapper = photoMapper;
    }
    @Autowired
    private GoodsPhotoInfoMapper photoMapper;
    //按店铺id查找商品
    public PageInfo<GoodsInfo> getGoodsListByShopId(Integer pn, Integer rn,String id) {
        PageHelper.startPage(pn, rn);

        List<GoodsInfo> list = mapper.selectGoodsByShopId(id);

        PageInfo p = new PageInfo(list);
        return p;
    }
    //按商品id查找商品具体类别
    public List<GoodsTypeInfo> getGoodsTypeListByGoodsId(String id){
        List<GoodsTypeInfo> list = mapper.selectGoodsTypeByGoodsId(id);
        return list;
    }
    //按商品id组查找商品具体类别组
    public List<List<GoodsTypeInfo>> getMultipleGoodsTypeListByGoodsIdList(List<String> idList){
        List<List<GoodsTypeInfo>> lList = new ArrayList<>();
        for(String id : idList){
            List<GoodsTypeInfo> list = mapper.selectGoodsTypeByGoodsId(id);
            lList.add(list);
        }
        return lList;
    }
    //查看是否有在售卖商品
    public boolean haveGoodsOnSale(String shopId){
        List<GoodsInfo> l = mapper.selectGoodsByIsSale(shopId);
        if(!l.isEmpty())
            return true;
        else
            return false;
    }
    //更改当前店铺所有商品售卖状态
    public void changeAllGoodsCondition(String shopId){
        if(!mapper.selectGoodsByIsSale(shopId).isEmpty())
            mapper.stopAllGoodsOnsale(shopId);
        else
            mapper.returnAllGoodsOnsale(shopId);
    }
    //更改单一商品售卖状态
    public void changeOneGoodsCondition(String goodsId){
        mapper.changeGoodsIsSale(goodsId);
    }
    //更新商品库存
    public void updateGoodsStock(String goodsTypeId,Integer stock,Double price){
        mapper.addGoodsStockandprice(goodsTypeId,stock,price);
    }
    //上架商品
    public void upGoods(GoodsInfo goods){
        mapper.insertGoods(goods);
    }
    //增加商品类别
    public void upGoodsType(GoodsTypeInfo goodsType){
        mapper.insertGoodsType(goodsType);
    }
    //下架商品
    public void deleteGoods(String goodsId){
        mapper.deleteGoods(goodsId);
        mapper.deleteGoodsTypeByGoodsId(goodsId);
        photoMapper.deletePhotoListByGoodsId(goodsId);
    }
}
