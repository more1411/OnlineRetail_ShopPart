package com.example.onlineretails.mapper;

import com.example.onlineretails.entity.GoodsInfo;
import com.example.onlineretails.entity.GoodsTypeInfo;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ShopGoodsMapper {
    //按店铺id查找商品
    @Select("select * from goods_info where shopId=#{id}")
    List<GoodsInfo> selectGoodsByShopId(@Param("id") String shopId);
    //查找所有商品
    @Select("select * from goods_info")
    List<GoodsInfo> selectAll();
    //更改某一商品售卖状态
    @Update("update goods_info set isSale=-isSale where goodsId=#{id}")
    int changeGoodsIsSale(@Param("id") String goodsId);
    //当前店铺暂停所有商品售卖
    @Update("update goods_info set isSale=-1 where shopId=#{id}")
    int stopAllGoodsOnsale(@Param("id") String shopId);
    //当前店铺恢复所有商品售卖
    @Update("update goods_info set isSale=1 where shopId=#{id}")
    int returnAllGoodsOnsale(@Param("id") String shopId);
    //查找在售卖商品
    @Select("select * from goods_info where shopId=#{id} and isSale=1")
    List<GoodsInfo> selectGoodsByIsSale(@Param("id") String shopId);
    //按商品id查找商品具体类别
    @Select("select * from goods_type_info where goodsId=#{id}")
    List<GoodsTypeInfo> selectGoodsTypeByGoodsId(@Param("id") String goodsId);
    //商品入库
    @Update("update goods_type_info set stock=#{stock},price=#{price} where goodsTypeId=#{goodsTypeId}")
    int addGoodsStockandprice(@Param("goodsTypeId")String goodsTypeId,@Param("stock")Integer stock,@Param("price")Double price);
    //添加新商品
    @Insert("insert into goods_info values(#{goods.goodsId},#{goods.goodsName},#{goods.goodsDescription},#{goods.goodsPhotosLink},#{goods.isSale},#{goods.goodsLabels},#{goods.shopId})")
    int insertGoods(@Param("goods") GoodsInfo goods);
    //添加商品新类别
    @Insert("insert into goods_type_info values(#{goodsType.goodsTypeId},#{goodsType.goodsId},#{goodsType.type},#{goodsType.price},#{goodsType.stock})")
    int insertGoodsType(@Param("goodsType") GoodsTypeInfo goodsType);
    //按类别id删除商品类别
    @Delete("delete from goods_type_info where goodsTypeId=#{id}")
    int deleteGoodsType(@Param("id") String id);
    //按商品id删除商品类别
    @Delete("delete from goods_type_info where goodsId=#{id}")
    int deleteGoodsTypeByGoodsId(@Param("id") String id);
    //删除商品
    @Delete("delete from goods_info where goodsId=#{id}")
    int deleteGoods(@Param("id") String id);
}
