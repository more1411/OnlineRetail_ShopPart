package com.example.onlineretails.service;

import com.example.onlineretails.entity.ShopApply;
import com.example.onlineretails.mapper.ShopApplyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShopApplyService {
    public void setMapper(ShopApplyMapper mapper) {
        this.mapper = mapper;
    }
    @Autowired
    private ShopApplyMapper mapper;
    //添加一个商铺申请
    public void insertShopApply(ShopApply apply){
        mapper.insertShopApply(apply);
    }
    //查找申请
    public List<ShopApply> findShopApply(String userId){
        List<ShopApply> apply=mapper.findShopApply(userId);
        return apply;
    }
}
