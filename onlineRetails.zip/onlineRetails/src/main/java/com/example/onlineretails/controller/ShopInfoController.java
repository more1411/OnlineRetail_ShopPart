package com.example.onlineretails.controller;

import com.example.onlineretails.entity.ShopApply;
import com.example.onlineretails.entity.ShopInfo;
import com.example.onlineretails.service.ShopApplyService;
import com.example.onlineretails.service.ShopInfoService;
import com.example.onlineretails.util.FileTools;
import com.example.onlineretails.util.JsonTools;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.example.onlineretails.util.IdTools.getId;

@RestController
@RequestMapping("/shopmessage")
public class ShopInfoController {
    public void setService(ShopInfoService service) {
        this.service = service;
    }

    public ShopInfoService getService() {
        return service;
    }

    @Autowired
    private ShopInfoService service;

    public ShopApplyService getApplyService() {
        return applyService;
    }

    public void setApplyService(ShopApplyService applyService) {
        this.applyService = applyService;
    }

    @Autowired
    private ShopApplyService applyService;
    //按用户id获取店铺信息
    @RequestMapping("/find.action")
    public String GetShopMessageByUserId(String userId){
        ShopInfo myShopMessage = service.getShopByUserId(userId);
        Map map = new LinkedHashMap();
        map.put("myShopMessage",myShopMessage);
        return JsonTools.querySuccess(map);
    }
    //商铺申请
    @RequestMapping("/apply.action")
    public String insertShopApply(String userId, MultipartFile pdfFile){
        ShopApply apply = new ShopApply();
        apply.setShopApplyId(getId());
        apply.setUserId(userId);
        apply.setApplyInfoLink(FileTools.writeFile("D:/applyPdfFile/","", pdfFile));
        Timestamp time = new Timestamp(System.currentTimeMillis());
        apply.setApplyTime(time);
        apply.setReplyTime(null);
        apply.setAgreed(null);
        applyService.insertShopApply(apply);
        return JsonTools.executeSuccess();
    }

    //检查店铺申请状态
    @RequestMapping("/checkapply.action")
    public String checkShopApply(String userId){
        List<ShopApply> apply = applyService.findShopApply(userId);
        Map map = new LinkedHashMap();
        map.put("apply",apply);
        return JsonTools.querySuccess(map);
    }
    //更改店面
    @RequestMapping("/changeShopPhoto.action")
    public String changeShopPhoto(String shopId,MultipartFile shopPhoto){
        FileTools.deleteFile("D:/image/shop/",service.getPhotoNameByShopId(shopId));
        service.updatePhoto(shopId,FileTools.writeFile("D:/image/shop/","",shopPhoto));
        return JsonTools.executeSuccess();
    }
}
