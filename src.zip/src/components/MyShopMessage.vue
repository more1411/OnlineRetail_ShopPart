<template>
	<el-container>
	  <el-aside width=40%>
		  <div class="imgplace">
		  		<el-image :src="shopPhotoLink+myshopmessage.shopPhotoLink" fit="contain"></el-image>
		  </div>
		  <el-divider></el-divider>
		  <el-divider></el-divider>
		  <el-button size="medium" type="primary" @click="changeShopPhoto()">更改店面图片</el-button>
	  </el-aside>
	  <el-main>
			<el-row>
			<el-col :span="24"><p class="centerword">我的店铺</p></el-col>
			</el-row>
			<el-row>
			<el-col :span="4" :offset="1"><p class="leftword">店名:</p></el-col>
			<el-col :span="19"><p class="leftword">{{myshopmessage.shopName}}</p></el-col>
			</el-row>
			<el-row>
			<el-col :span="4" :offset="1"><p class="leftword">商家介绍:</p></el-col>
			<el-col :span="19"><p class="leftword">{{myshopmessage.shopDescription}}</p></el-col>
			</el-row>
			<el-row>
			<el-col :span="4" :offset="1"><p class="leftword">店址:</p></el-col>
			<el-col :span="19"><p class="leftword">{{myshopmessage.shopAddress}}</p></el-col>
			</el-row>
	  </el-main>
	  
	  <el-dialog
	    title="更改店面"
	    :visible.sync="changeShopPhotoVisible"
	    width="40%">
	    <div>
	  	  <el-form :model="shopPhoto" label-width="80px">
	  	  <el-form-item label="上传图片">
	  	    <el-upload ref="shopPhoto" action="#" list-type="picture-card" :on-change="handleChangePics" :auto-upload="false" :multiple="false">
	  	      <i slot="default" class="el-icon-circle-plus-outline"></i>
	  	      <div slot="file" slot-scope="{file}">
	  	        <img width="100%"   fit="cover" :src="file.url" alt="">
	  	        <span class="el-upload-list__item-actions">
	  	          <span class="el-upload-list__item-preview" @click="handlePictureCardPreview(file)">
	  	            <i class="el-icon-zoom-in"></i>
	  	          </span>
	  	          <span class="el-upload-list__item-delete" @click="handleRemove(file)">
	  	            <i class="el-icon-delete"></i>
	  	          </span>
	  	        </span>
	  	      </div>
	  	    </el-upload>
	  	  </el-form-item>
	  	  <el-form-item>
	  		  <el-button type="primary" @click="photoSubmit()">提交</el-button>
	  	  </el-form-item>
	  	  </el-form>
	    </div>
	  </el-dialog>
	  <el-dialog :visible.sync="photoPreviewVisible">
	    <img width="100%" :src="dialogImageUrl" alt="">
	  </el-dialog>
	</el-container>
	
</template>

<script>
	export default{
		data(){
			return{
				dialogImageUrl:null,
				photoPreviewVisible:false,
				shopPhoto:null,
				changeShopPhotoVisible:false,
				//myShopId:"00001",
				//myUserId:this.$route.query.userId,
				myshopmessage:[],
				shopPhotoLink:"http://localhost:8088/image/shop/",
			}
		},
		methods:{
			loadmyshopmessage(){
				this.ajax.request({
					url:'/shopmessage/find.action',
					params:{
						userId:this.$route.query.userId
					}
				}).then((p)=>{
					if(!p.data.code){
						this.myshopmessage=p.data.result.myShopMessage;
					}
				})
			},
			handleChangePics(file, fileList) {
			  this.shopPhoto = fileList;
			
			},
			//删除图片（文件）的处理函数
			handleRemove(file) {
			  let files = this.$refs.shopPhoto.uploadFiles
			
			  for(let i=0; i<files.length; i++){
			    console.log(files[i],file)
			    if(files[i].uid==file.uid){
			      files.splice(i,1);
			    }
			  }
			},
			//查看原图的处理
			handlePictureCardPreview(file) {
			  this.dialogImageUrl = file.url;
			  this.photoPreviewVisible = true;
			},
			//更改店面图片
			changeShopPhoto(){
				this.changeShopPhotoVisible=true;
				let files = this.$refs.shopPhoto.uploadFiles;
				files.splice(0,files.length);
			},
			//上传店面图片
			photoSubmit(){
				let fd=new FormData();
				fd.append('shopId',this.$route.query.shopId)
				fd.append('shopPhoto',this.shopPhoto[0].raw,this.shopPhoto[0].name);
				this.ajax.request({
				url:'/shopmessage/changeShopPhoto.action',
				data:fd,
				method:'post',
				}).then((p)=>{
					if(!p.data.code){
						this.loadmyshopmessage();
						this.changeShopPhotoVisible=false;
					}
				})
			}
			
		},
		created() {
		this.loadmyshopmessage();
		}
	}
</script>

<style>
	.centerword{
		text-align: center;
	}
	.leftword{
		text-align: left;
	}
	.imgplace{
		height: 70%;
		width: 100%;
	}
</style>
