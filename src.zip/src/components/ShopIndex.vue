<template>
		<el-container>
			<el-aside width="200px" class="white">
				<el-menu default-active="1" text-color="darkblue" active-text-color="#ff6700" :router="true">
				  <el-menu-item index="/shopindex/mygoods" 
				  :route="{ path: '/shopindex/mygoods',
				   query: { shopId:this.$route.query.shopId ,
				   userId:this.$route.query.userId } }">
				    <i class="el-icon-s-goods"></i>
				    <span slot="title">我的商品</span>
				  </el-menu-item>
				  <el-menu-item index="/shopindex/myorder">
				    <i class="el-icon-s-order"></i>
				    <span slot="title">我的订单</span>
				  </el-menu-item>
				  <el-menu-item index="/shopindex/myshopmessage" 
				  :route="{ path: '/shopindex/myshopmessage', 
				  query: { shopId:this.$route.query.shopId,
				  userId:this.$route.query.userId } }">
				    <i class="el-icon-s-shop"></i>
				    <span slot="title">管理我的店铺</span>
				  </el-menu-item>
				  <el-menu-item index="/shopindex">
				    <i class="el-icon-back"></i>
				    <span slot="title">离开我的店铺</span>
				  </el-menu-item>
				</el-menu>
			</el-aside>
			<el-main class="white"><router-view></router-view></el-main>
		</el-container>
</template>

<script>
	export default{
		data(){
			return{
			}
		}
	}
</script>

<style>
	.el-header {
	    background-color: #B3C0D1;
	    color: #333;
	    text-align: center;
	    height: 200px;
	  }
	  
	  .el-aside {
	    background-color: #D3DCE6;
	    color: #333;
	    text-align: center;
		height:100%;
	  }
	  
	  .el-main {
	    background-color: #E9EEF3;
	    color: #333;
	    text-align: center;
		height:100%;
		margin: 0px;
		padding: 0px;
	  }
	  
	  .el-container {
		  height: 98%;
	  }
	  .lightblue {
	  	background-color: #3ed2ff;
	  }
	  .white{
		  background-color: #FFFFFF;
	  }
	  
</style>
