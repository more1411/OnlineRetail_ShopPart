<template>
	<div class="mainpart">
		<el-dialog
	  title="店铺申请"
	  :visible.sync="applyVisible"
	  width="40%">
	  <p class="message">请将申请店铺相关文件整合成一个pdf文档并上传，平台将会根据您的用户信息来生成店铺相关信息.</p>
	  <el-divider></el-divider>
	  <el-form :model="applyFile" label-width="80px">
	  <el-form-item label="上传文件">
	    <el-upload ref="applyFile" action="#" list-type="text" 
	    :on-change="handleChangePics" 
	    :auto-upload="false" 
	    :multiple="false" 
	    :limit="1"
	    :file-list="applyFile"
	    :on-exceed="handleExceed">
	     <el-button size="small" type="primary">选择文件</el-button>
	    </el-upload>
	  </el-form-item>
	  <el-form-item>
	  	<el-button type="primary" @click="submitApply()">提交</el-button>
	  </el-form-item>
	  </el-form>
	</el-dialog>
	<el-container class="haveapply">
	  <el-header>已发送申请</el-header>
	  <el-main>
		  <el-table
		        :data="myApplyView"
		        style="width: 100%">
		        <el-table-column
		          prop="applyTime"
		          label="申请时间"
		          width="180">
		        </el-table-column>
		        <el-table-column
		          prop="replyTime"
		          label="回复时间"
		          width="180">
		        </el-table-column>
		        <el-table-column
		          prop="result"
		          label="结果">
		        </el-table-column>
		      </el-table>
			  <el-divider></el-divider>
			  <el-row>
				  <el-col :span="24"><el-button size="small" type="primary" @click="applyForShop()">请求店铺</el-button></el-col>
			  </el-row>
	  </el-main>
	</el-container>
	</div>
	
</template>

<script>
	export default{
		data(){
			return{
				applyVisible:false,
				applyFile:null,
				myUserId:"000001",
				myApply:[],
				haveApply : false,
				myApplyView:[],
				canApply:true,
				haveShop:false
			}
		},
		methods:{
			//从后端获取已发出的申请
			checkapply(){
				this.ajax.request({
				  url:'/shopmessage/checkapply.action',
				  params:{
					  userId:this.myUserId
				  }
				}).then((p)=>{
					if(!p.data.code){
						this.myApply=p.data.result.apply;
						this.changeApply();
					}
				})
			},
			//转换申请格式
			changeApply(){
				this.myApplyView=[];
				if(this.myApply==null){
					this.haveApply=false;
				}
				else{
					this.haveApply=true;
					for(let a in this.myApply){
						this.myApplyView.push({
							applyTime:null,
							replyTime:null,
							result:null,
						})
						this.myApplyView[a].applyTime=this.myApply[a].applyTime;
						if(this.myApply.replyTime!=null)
						this.myApplyView[a].replyTime=this.myApply[a].replyTime;
						else
						this.myApplyView[a].replyTime="—— —— —— ——"
						if(this.myApply[a].agreed!=null){
							if(this.myApply[a].agreed==0)
							this.myApplyView[a].result="未通过";
							else{
								this.myApplyView[a].result="已通过";
								this.canApply=false;
								this.haveShop=true;
							}
						}
						else{
							this.myApplyView[a].result="未审核";
							this.canApply=false;
						}
					}
				}
			},
			findmyshop(){
				this.ajax.request({
					url:'/shopmessage/find.action',
					params:{
						userId:this.myUserId
					}
				}).then((p)=>{
					if(!p.data.code){
						if(p.data.result.myShopMessage!=null)
						this.$router.push({path:'/shopindex',query:{
							shopId:p.data.result.myShopMessage.shopId,
							userId:this.myUserId
							}})
					}
				})
			},
			//删除即将上传的文件
			handleRemove(file){
				let files = this.$refs.applyFile.uploadFiles;
				for(let i=0; i<files.length; i++){
				  if(files[i].uid==file.uid){
				    files.splice(i,1);
				  }
				}
			},
			handleChangePics(file, fileList) {
			  this.applyFile = fileList;
			},
			 handleExceed(files, fileList) {
			        this.$message.warning(`只能选择一个文件上传`);
			},
			submitApply(){
				let fd=new FormData();
				fd.append('userId',this.myUserId)
				fd.append('pdfFile',this.applyFile[0].raw,this.applyFile[0].name);
				this.ajax.request({
				  url:'/shopmessage/apply.action',
				  data:fd,
				  method:'post',
				}).then((p)=>{
					if(!p.data.code){
						this.checkapply();
						this.applyVisible=false;
					}
				})
				
			},
			//请求店铺
			applyForShop(){
				if(this.haveShop==true)
				this.$message('您的申请已通过，正在为您注册店铺，请耐心等待一到两个工作日');
				else if(this.canApply==false)
				this.$message({
				          message: '你还有未被审核的申请，请耐心等待一到两个工作日',
				          type: 'warning'
				        });
				else
				this.applyVisible=true;
			}
		},
		created() {
			this.findmyshop();
			this.checkapply();
			
		}
	}
</script>

<style>
	.mainpart{
		position: absolute;
		background-color: #aaff7f;
		height: 60%;
		width: 50%;
		left: 25%;
		margin-top:100px;
	}
	.message{
		margin: 10px 30px;
		text-align: left;
	}
	.haveapply{
		height:100%;
		width: 100%;
	}
</style>
