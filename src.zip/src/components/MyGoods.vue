<template>
	<el-container>
		
		<el-header class="lightblue">
			<el-row type="flex" justify="end">
				<el-button class="centerbutton" @click="getId(),openUpGoodsDialog(myshopid)">上架商品</el-button>
				<el-button class="centerbutton" @click="changeshopcondition()" v-if="havegoodsonsale==true">暂停营业</el-button>
				<el-button class="centerbutton" @click="changeshopcondition()" v-if="havegoodsonsale==false">恢复营业</el-button>
			</el-row>
		</el-header>
		
		<el-main>
			<el-row :gutter="20">
			  <el-card class="box-card" v-for="(g,index) in shopgoods" :key="'01'+index">
				  
			    <div slot="header" class="clearfix title">
			      <span>{{g.goodsName}}</span>
			      <el-button style="float: right; padding: 3px 0" type="text" @click="changeonegoodscondition(g.goodsId)" v-if="g.isSale==1">暂停售卖</el-button>
				  <el-button style="float: right; padding: 3px 0" type="text" @click="changeonegoodscondition(g.goodsId)" v-if="g.isSale==-1">恢复售卖</el-button>
				  <el-button style="float: right; padding: 3px 0" type="text" @click="deleteGoods(g.goodsId)">下架商品</el-button>
				  <el-button style="float: right; padding: 3px 0" type="text" @click="manageShopGoodsPhotos(index)">管理商品图片</el-button>
			    </div>
			    <div class="text item">
					<el-container>
					  <el-aside class="white" width=40%>
						  <div class="block">
						      <el-carousel height="300px">
						        <el-carousel-item v-for="(image,index2) in goodsImage[index]" :key="'101'+index2">
						          <el-image :src="goodsPhotoHeadLink+image.goodsPhotoLink" fit="contain"></el-image>
						        </el-carousel-item>
						      </el-carousel>
						    </div>
						  		<el-row type="flex" justify="start">
						  			<span class="money">{{'¥'+minmaxmoney[index]}}</span>
						  		</el-row>
						  		<el-row type="flex" justify="start">
						  			<el-collapse>
						  				<el-collapse-item title="描述信息" name="g">
						  					<div class="text" v-if="g.goodsDescription!='null'">{{g.goodsDescription}}</div>
											<div class="text" v-else>商家很懒，什么都没有写</div>
						  				</el-collapse-item>
						  			</el-collapse>
						  		</el-row>	  
					  </el-aside>
					  <el-main class="white">
						  		<template>
						  		  <el-table
						  		    :data="goodsmessage[index]"
						  		    height=100%
						  		    style="width: 100%">
						  		    <el-table-column
										prop="type"
						  		      label="样式"
						  		      width="90">
						  		    </el-table-column>
						  		    <el-table-column
									prop="price"
						  		      label="价格"
						  		      width="90">
						  		    </el-table-column>
						  		    <el-table-column
									prop="stock"
						  		      label="库存"
									  width="90">
						  		    </el-table-column>
									<el-table-column
										  fixed="right"
									      width="300">
									      <template slot-scope="scope">
													<el-button type="primary" size="small" icon="el-icon-edit" @click="upSPdialogVisible = true,creatOldGoodsType(scope)" circle></el-button>
									      </template>
									    </el-table-column>
						  		  </el-table>
						  		</template>
						  	</el-main> 
					</el-container>
			    </div>
			  </el-card>
			</el-row>
			
			<el-dialog
			  title="更新商品数据"
			  :visible.sync="upSPdialogVisible"
			  width="30%"
			  :closed="handleClose()">
			  <el-form :model="goodsType">
			    <el-form-item>
			  					<el-row>
			  					  <el-col :span="12"><el-input v-model="goodsType.stock" placeholder="入库"></el-input></el-col>
			  					  <el-col :span="12"><el-input v-model="goodsType.ustock" placeholder="出库"></el-input></el-col>
			  					</el-row>
			    </el-form-item>
			    <el-form-item>
			  					<el-input v-model="goodsType.price" placeholder="更改价格"></el-input>
			    </el-form-item>
			    <el-form-item>
			      <el-button type="primary" @click="changeTypeMessage()">提交</el-button>
			  				  <el-button type="primary" @click="upSPdialogVisible = false">取消</el-button>
			    </el-form-item>
			  </el-form>
			</el-dialog>
			
			<el-dialog
			  title="上架"
			  :visible.sync="upGoodsVisible"
			  width="60%"
			  :closed="upGoodsHandleClose()">
			  <div>
			  	<el-form :model="upGoodsForm" :ref="upGoodsForm" :rules="rules" label-width="100px" lable-position="left">
						<el-form-item 
							label="商品名称"
							prop="goodsName"
							>
			  					<el-input v-model="upGoodsForm.goodsName" placeholder="请输入商品名称"></el-input>
						</el-form-item>
						
						<el-row v-for="(type, index) in upGoodsForm.goodsType" :key="'110'+index">
							<el-col :span="12">
								<el-form-item
									label-width="100px"
									:label="'类别'+Number(index+1)"
									:prop="'goodsType.'+index+'.type'"
									:rules="[{required:true,message:'类型名不能为空',trigger: 'blur' }]">
										<el-input v-model="type.type" placeholder="类型名称"></el-input>
								</el-form-item>
							</el-col>
							<el-col :span="4">
								<el-form-item
									label-width="0px"
									:prop="'goodsType.'+index+'.price'"
									:rules="[
						{required:true,message:'价格不能为空',trigger: 'blur' },
						{type:'number',message:'价格必须为数字',trigger: 'blur' }]"
									>
										<el-input v-model.number="type.price" placeholder="价格"></el-input>
								</el-form-item>
							</el-col>
							<el-col :span="4">
								<el-form-item
									label-width="0px"
									:prop="'goodsType.'+index+'.stock'"
									:rules="[
						{required:true,message:'库存不能为空（可以为0）',trigger: 'blur' },
						{type:'number',message:'库存必须为数字',trigger: 'blur' }]"
									>
									<el-input v-model.number="type.stock" placeholder="库存"></el-input>
								</el-form-item>
							</el-col>
							<el-col :span="4">
								<el-form-item label-width="0px">
										<el-button icon="el-icon-delete" @click.prevent="removeGoodsType(type)" type="text"></el-button>
								</el-form-item>
							</el-col>
						</el-row>
			  			<el-form-item >
								<el-row>
									<el-col :span="3"><el-button icon="el-icon-circle-plus-outline" @click="addGoodsType()" class="text" circle></el-button></el-col>
								</el-row>
			  			</el-form-item>
						<el-form-item label="商品标签">
								<el-input type="textarea" v-model="upGoodsForm.goodsLabel"></el-input>
						</el-form-item>
						<el-form-item label="商品描述">
								<el-input type="textarea" v-model="upGoodsForm.goodsDescription"></el-input>
						</el-form-item>
				<el-form :model="uploadPics" label-width="100px">
				<el-form-item label="选择商品图片">
				  <el-upload ref="uploadPics" action="#" list-type="picture-card" :on-change="handleChangePics" :auto-upload="false" :multiple="true">
				    <i slot="default" class="el-icon-circle-plus-outline"></i>
				    <div slot="file" slot-scope="{file}">
				      <img width="100%"   fit="cover" :src="file.url" alt="">
				      <span class="el-upload-list__item-actions">
				        <span class="el-upload-list__item-preview" @click="handlePictureCardPreview(file)">
				          <i class="el-icon-zoom-in"></i>
				        </span>
				        <span class="el-upload-list__item-delete" @click="handleRemove(file)">
				          <i class="el-icon-delete"></i>
				        </span>
				      </span>
				    </div>
				  </el-upload>
				</el-form-item>
				</el-form>
				<el-form-item>
				<el-row>
					<el-col :span="6":offset="6"><el-button type="primary" @click="submitGoods(),submitGoodsType()">提交</el-button></el-col>
					<el-col :span="6"><el-button type="primary" @click="upGoodsVisible = false">取消</el-button></el-col>
				</el-row>
				</el-form-item>
				</el-form>
			  </div>
			</el-dialog>
			
			<el-dialog
			  title="管理商品图片"
			  :visible.sync="manageShopGoodsPhotosVisible"
			  width="70%">
			  <div>
				  <el-row v-for="(mim,index) in oneGoodsImage" :gutter="20">
				  		<el-col :span="4" v-for="(nim,index2) in mim" :key="'1001'+index2">
				  			<el-image :src="goodsPhotoHeadLink+nim.im.goodsPhotoLink" fit="contain"></el-image>
							<el-button type="primary" size="small" icon="el-icon-delete" @click="deletePhoto(nim.im.goodsPhotoId)" circle></el-button>
				  		</el-col>
				  </el-row>
			  </div>
			  <el-divider></el-divider>
			  <div>
				  <el-form :model="uploadPics" label-width="80px">
				  <el-form-item label="上传图片">
				    <el-upload ref="uploadPics" action="#" list-type="picture-card" :on-change="handleChangePics" :auto-upload="false" :multiple="true">
				      <i slot="default" class="el-icon-circle-plus-outline"></i>
				      <div slot="file" slot-scope="{file}">
				        <img width="100%"   fit="cover" :src="file.url" alt="">
				        <span class="el-upload-list__item-actions">
				          <span class="el-upload-list__item-preview" @click="handlePictureCardPreview(file)">
				            <i class="el-icon-zoom-in"></i>
				          </span>
				          <span class="el-upload-list__item-delete" @click="handleRemove(file)">
				            <i class="el-icon-delete"></i>
				          </span>
				        </span>
				      </div>
				    </el-upload>
				  </el-form-item>
				  <el-form-item>
					  <el-button type="primary" @click="photoSubmit()">提交</el-button>
				  </el-form-item>
				  </el-form>
			  </div>
			</el-dialog>
			<el-dialog :visible.sync="photoPreviewVisible">
			  <img width="100%" :src="dialogImageUrl" alt="">
			</el-dialog>
		</el-main>
		
		<el-footer height="30px">
			<el-pagination background layout="total, prev, pager, next, jumper" :page-size="page.rn"
			:total="page.total" @size-change="changePageSize" @current-change="changeCurrPage">
			</el-pagination>
		</el-footer>
		
	</el-container>
</template>

<script>
	export default{
		data(){
			return{
				page: {
				  total: 0,
				  pn: 1,
				  rn: 10
				},
				upSPdialogVisible:false,
				upGoodsVisible:false,
				manageShopGoodsPhotosVisible:false,
				photoPreviewVisible:false,
				dialogImageUrl:null,
				myshopid : "00001",
				randomId : null,
				goodsIndexOfMangePhoto:null,
				shopgoods : [],
				goodsmessage : [],
				minmaxmoney : [],
				havegoodsonsale:false,
				thisGoodsIndex:null,
				goods:{
					goodsId:null
				},
				goodsType:{
					goodsTypeId:null,
					stock:null,
					ustock:null,
					price:null
				},
				oldGoodsType:{
					stock:null,
					price:null
				},
				upGoodsForm:{
					goodsName:null,
					goodsType:[{
						type:null,
						price:null,
						stock:null
					}],
					goodsLabel:null,
					goodsDescription:null
				},
				uploadPics:[],
				goodsImage:[],
				oneGoodsImage:[[]],
				goodsPhotoHeadLink:"http://localhost:8088/image/goods/",
				fil:[],
				rules:{
					goodsName:[
						{required:true,message:"商品名不能为空",trigger: 'blur' }
					]
				}
			}
		},
		methods: {
			//加载商品信息
			loadgoods() {
				this.myshopid=this.myshopid;
				let params = {
				  pn: this.page.pn,
				  rn: this.page.rn,
				  id : this.myshopid,
				  }
			this.ajax.request({
			url: '/shopgoods/find.action',
			params
			}).then((p) => {	
				if (!p.data.code) {
				  this.shopgoods = p.data.result.goods;
				  this.page.total = p.data.result.total;
				  this.goodsmessage = p.data.result.goodsMessage;
				  this.minmaxmoney = p.data.result.minMaxMoney;
				  this.havegoodsonsale = p.data.result.haveGoodsOnSale;
				  this.goodsImage = p.data.result.goodsPhotoList;
				  this.page.total=p.data.result.total;
				}
			})
			},
			//改变店铺状态（暂停营业，开始营业）
			changeshopcondition(){
				this.ajax.request({
					url:'/shopgoods/changeallcondition.action',
					params:{
						shopId:this.myshopid
					}
				}).then((p)=>{
					if(!p.data.code){
						this.loadgoods();
					}
				})
			},
			//改变单个商品的售卖状态
			changeonegoodscondition(goodsId){
				this.ajax.request({
					url:'/shopgoods/changeonecondition.action',
					params:{
						goodsId
					}
				}).then((p)=>{
					if(!p.data.code){
						this.loadgoods();
					}
				})
			},
			//更改库存,价格
			changeTypeMessage(){
				let s = Number(this.oldGoodsType.stock)+Number(this.goodsType.stock)-Number(this.goodsType.ustock);
				let p =(this.goodsType.price==null?this.oldGoodsType.price:this.goodsType.price);
				this.ajax.request({
					url:'/shopgoods/updateSP.action',
					params:{
							goodsTypeId:this.goodsType.goodsTypeId,
							stock:s,
							price:p,
						}
				}).then((p)=>{
					if(!p.data.code){
						this.loadgoods();
					}
				})
				this.upSPdialogVisible = false;
			},
			//商品信息更新表关闭
			handleClose(){
			},
			//商品上架表关闭
			upGoodsHandleClose(){
				
			},
			//商品更新表单更新
			creatOldGoodsType(scope){
				this.goodsType.goodsTypeId=scope.row.goodsTypeId;
				this.goodsType.stock=null;
				this.goodsType.ustock=null;
				this.goodsType.price=null;
				this.oldGoodsType.stock=scope.row.stock;
				this.oldGoodsType.price=scope.row.price;
			},
			//增加商品种类表单项
			addGoodsType() {
			        this.upGoodsForm.goodsType.push({
			          typeName: '',
					  typePrice:'',
					  typeStock:'',
			        });
			},
			//减少商品种类表单项
			removeGoodsType(item) {
			        let index = this.upGoodsForm.goodsType.indexOf(item)
			        if (index !== -1) {
			          this.upGoodsForm.goodsType.splice(index, 1)
			        }
			},
			//打开商品上架表
			openUpGoodsDialog(shopid){
				this.upGoodsForm.goodsName=null;
				this.upGoodsForm.goodsDescription=null;
				this.upGoodsForm.goodsLabel=null;
				this.upGoodsForm.goodsType=[];
				this.upGoodsForm.goodsType.push({
				  type: '',
				  price:'',
				  stock:'',
				});
				this.upGoodsVisible = true;
				let files = this.$refs.uploadPics.uploadFiles;
				files.splice(0,files.length);
			},
			//提交上架商品信息
			submitGoods() {
				let fd = new FormData();
				fd.append('goodsId',this.randomId);
				fd.append('shopId',this.myshopid);
				fd.append('goodsName',this.upGoodsForm.goodsName);
				fd.append('goodsLabels',this.upGoodsForm.goodsLabel);
				fd.append('goodsDescription',this.upGoodsForm.goodsDescription);
				for(let i=0; i<this.uploadPics.length; i++){
				  fd.append('goodsPhoto',this.uploadPics[i].raw,this.uploadPics[i].filename);
				}
				
				this.ajax.request({
				  url:'/shopgoods/upGoods.action',
				  data:fd,
				  method:'post',
				}).then((p)=>{
					if(!p.data.code){
					this.upGoodsVisible = false;
					this.loadgoods();
					}
				})
			},
			//增加商品类型
			submitGoodsType(goodsId){
				for(let type in this.upGoodsForm.goodsType){
					let fd = new FormData();
					fd.append('goodsId',this.randomId);
					fd.append('type',this.upGoodsForm.goodsType[type].type)
					fd.append('price',this.upGoodsForm.goodsType[type].price)
					fd.append('stock',this.upGoodsForm.goodsType[type].stock)
					fd.append("goodsTypeId",type.toString())
					this.ajax.request({
					  url:'/shopgoods/upGoodsType.action',
					  data:fd,
					  method:'post',
					})
				}
				this.loadgoods();
			},
			//打开当前商品图片增删改界面
			manageShopGoodsPhotos(i){
				this.manageShopGoodsPhotosVisible = true;
				this.thisGoodsIndex=i;
				let files = this.$refs.uploadPics.uploadFiles;
				files.splice(0,files.length);
				this.oneGoodsImage=[[]];
				this.goodsIndexOfMangePhoto = i;
				let num=0;
				let pagenum=0;
				for(let index in this.goodsImage[i]){
					if(num<=5){
						this.oneGoodsImage[pagenum].push({im:this.goodsImage[i][index]});
						num++;
					}
					else{
						num=0;
						pagenum++;
						this.oneGoodsImage.push([]);
						this.oneGoodsImage[pagenum].push({im:this.goodsImage[i][index]});
					}
				}
			},
			//上传图片查看预览
			handlePictureCardPreview(file) {
			  this.dialogImageUrl = file.url;
			  this.photoPreviewVisible = true;
			},
			//上传图片中删除图片
			handleRemove(file) {
			  let files = this.$refs.uploadPics.uploadFiles;
			  for(let i=0; i<files.length; i++){
			    if(files[i].uid==file.uid){
			      files.splice(i,1);
			    }
			  }
			},
			//上传图片
			photoSubmit(){
				let fd = new FormData();
				fd.append('goodsId',this.shopgoods[this.goodsIndexOfMangePhoto].goodsId);
				for(let i=0; i<this.uploadPics.length; i++){
				  fd.append('picsFile',this.uploadPics[i].raw,this.uploadPics[i].filename);
				}
				this.ajax.request({
				  url:'/shopgoods/oneUpdatePhoto.action',
				  data:fd,
				  method:'post',
				}).then((p)=>{
					if(!p.data.code){
						let files = this.$refs.uploadPics.uploadFiles;
						files.splice(0,files.length);
					}
				})
				this.loadgoods();
				this.manageShopGoodsPhotos(this.thisGoodsIndex);
			},
			//选择的图片（文件）改变（添加或删除）
			handleChangePics(file, fileList) {
			  this.uploadPics = fileList;
			},
			//获取随机id
			getId(){
				this.ajax.request({
				  url:'/shopgoods/getId.action',
				}).then((p) => {	
				if (!p.data.code) {
				  this.randomId=p.data.result.id;
				}
			})
			},
			deletePhoto(id){
				this.ajax.request({
				  url:'/shopgoods/deletePhoto.action',
				  params:{
					  photoId:id
				  }
				}).then((p) => {	
				if (!p.data.code) {
				  this.loadgoods();
				  this.manageShopGoodsPhotos(this.thisGoodsIndex);
				}
				})
			},
			changePageSize(size) {
			  this.page.rn = size;
			  this.loadgoods()
			},
			changeCurrPage(page) {
			  this.page.pn = page;
			  this.loadgoods()
			},
			//下架商品
			deleteGoods(gId){
				this.ajax.request({
				  url:'/shopgoods/deletegoods.action',
				  params:{
					  goodsId:gId
				  }
				}).then((p) => {	
				if (!p.data.code) {
				  this.loadgoods();
				}
				})
			}
			
		},
		created() {
		this.loadgoods()
		}
	}
</script>

<style>
	.title{
		text-align: left;
	}
	.text {
	    font-size: 14px;
		text-align: left;
	  }
	
	  .item {
	    margin-bottom: 10px;
	  }
	  .clearfix:before,
	    .clearfix:after {
	      display: table;
	      content: "";
	    }
	    .clearfix:after {
	      clear: both
	    }
	.el-card {
			margin-bottom: 10px;
	}
	.blue {
		background-color: #2e7fe1;
	}
	.lightblue {
		background-color: #3ed2ff;
	}
	.money {
		font-size: 18px;
		color : #ce0000;
	}
	.goodbutton {
		margin-bottom: 15px;
		font-size: 20px;
	}
	.centerbutton {
		margin-top: 10px;
	}
	.white{
			  background-color: #FFFFFF;
	}
	
</style>
