import Vue from 'vue'
import Router from 'vue-router'
import ShopIndex from '@/components/ShopIndex'
import MyGoods from '@/components/MyGoods'
import MyOrder from '@/components/MyOrder'
import MyShopMessage from '@/components/MyShopMessage'
import ShopApply from '@/components/ShopApply'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path:'/',
      redirect:'/shopapply'
    },{
		path:'/shopindex',
		component:ShopIndex,
		children:[
		  {
		    path:'/shopindex/mygoods',
		    component:MyGoods
		  },
			{
			  path:'/shopindex/myorder',
			  component:MyOrder
			},
			{
				path:'/shopindex/myshopmessage',
				component:MyShopMessage
			}
		]
    },{
		path:'/shopapply',
		component:ShopApply
	}
  ]
})
